declare module 'air-datepicker/locale/fi' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const fi: AirDatepickerLocale;

    export default fi;
}
