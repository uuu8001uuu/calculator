declare module 'air-datepicker/locale/nl' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const nl: AirDatepickerLocale;

    export default nl;
}
