declare module 'air-datepicker/locale/de' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const de: AirDatepickerLocale;

    export default de;
}
